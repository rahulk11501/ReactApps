import { Component } from 'react'
import fetch from 'isomorphic-fetch'

class MemberList extends Component {
    render() {
        return (
            <div className="member-list">
            	<h1>Society Members</h1>
            </div>
        )    
   }     
}

export default MemberList