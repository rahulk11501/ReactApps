export const AddDayForm = () => (
	<h1>Add A Day</h1>
)